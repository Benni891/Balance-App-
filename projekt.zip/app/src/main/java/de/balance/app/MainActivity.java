package de.balance.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_FILE = 1;
    WebView web;
    ValueCallback<Uri[]> chooserCb;
    Uri camUri;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        // Kein Screenshot / keine Vorschau im App-Wechsler: Gesundheitsdaten bleiben privat
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSaveFormData(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return asset(u.getPath());
                if ("api.anthropic.com".equals(u.getHost())) return null; // einzige erlaubte externe Verbindung
                return deny();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    String[] types = p.getAcceptTypes();
                    boolean image = types == null || types.length == 0 || (types[0] != null && types[0].startsWith("image"));
                    Intent cam = null;
                    if (image) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "balance_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                    }
                    if (image && p.isCaptureEnabled()) { startActivityForResult(cam, REQ_FILE); return true; }
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType(image ? "image/*" : "*/*");
                    Intent ch = Intent.createChooser(pick, image ? "Foto wählen" : "Datei wählen");
                    if (cam != null) ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                    startActivityForResult(ch, REQ_FILE);
                } catch (Exception e) { chooserCb = null; cb.onReceiveValue(null); return false; }
                return true;
            }
        });
        web.loadUrl("https://" + HOST + "/index.html");
    }

    WebResourceResponse asset(String path) {
        if (path == null || path.equals("/")) path = "/index.html";
        String name = path.substring(1);
        if (name.contains("..") || name.equals("sw.js")) return notFound();
        try {
            InputStream in = getAssets().open("www/" + name);
            String mime = name.endsWith(".html") ? "text/html" : name.endsWith(".js") ? "application/javascript"
                    : name.endsWith(".css") ? "text/css" : name.endsWith(".png") ? "image/png"
                    : name.endsWith(".webmanifest") ? "application/manifest+json" : "application/octet-stream";
            return new WebResourceResponse(mime, "utf-8", in);
        } catch (Exception e) { return notFound(); }
    }
    WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
    }
    WebResourceResponse deny() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || chooserCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK) {
            if (data != null && data.getData() != null) out = new Uri[]{data.getData()};
            else if (camUri != null) out = new Uri[]{camUri};
        }
        if (out == null && camUri != null) { try { getContentResolver().delete(camUri, null, null); } catch (Exception ignored) {} }
        chooserCb.onReceiveValue(out);
        chooserCb = null; camUri = null;
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }

    class Bridge {
        @JavascriptInterface public void saveFile(String name, String content) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(content.getBytes(StandardCharsets.UTF_8)); }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Backup im Ordner „Downloads“ gespeichert", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export fehlgeschlagen", Toast.LENGTH_LONG).show());
            }
        }
    }
}
